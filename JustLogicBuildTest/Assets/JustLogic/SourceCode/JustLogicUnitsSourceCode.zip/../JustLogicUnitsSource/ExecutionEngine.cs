﻿using System;

namespace JustLogic.Core
{
    /// <summary>
    /// An executor for units tree
    /// </summary>
    [Serializable]
    public class ExecutionEngine : ExecutionEngineBase
    {

    }
}