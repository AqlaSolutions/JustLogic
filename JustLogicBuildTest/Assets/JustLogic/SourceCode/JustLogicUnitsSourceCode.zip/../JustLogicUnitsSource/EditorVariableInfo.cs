﻿using System;

namespace JustLogic.Core
{
    /// <tocexclude />
    /// <inheritdoc />
    [Serializable]
    public class EditorVariableInfo : EditorVariableInfoBase
    {
    }
}