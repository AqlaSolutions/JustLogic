﻿using System;
using JustLogic.Core;

[UnitMenu("Logical/Compare Event Argument")]
[UnitMenu("Event/Compare Argument")]
[UnitFriendlyName("Compare Event Argument")]
public class JLCompareEventArgument : JLCompareEventArgumentBase
{

}
