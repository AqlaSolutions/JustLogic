﻿using JustLogic.Core;
using UnityEngine;

[UnitMenu("Debug/Print and Ret")]
public class JLPrintRet : JLPrintRetBase
{

}