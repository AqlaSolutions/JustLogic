﻿using JustLogic.Core;

[UnitMenu("Logical/And")]
public class JLAnd : JLAndBase
{

}