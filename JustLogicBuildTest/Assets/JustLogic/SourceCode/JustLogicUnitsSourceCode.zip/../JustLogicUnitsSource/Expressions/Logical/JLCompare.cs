﻿using System;
using JustLogic.Core;

[UnitMenu("Logical/Compare")]
public class JLCompare : JLCompareBase2
{

}