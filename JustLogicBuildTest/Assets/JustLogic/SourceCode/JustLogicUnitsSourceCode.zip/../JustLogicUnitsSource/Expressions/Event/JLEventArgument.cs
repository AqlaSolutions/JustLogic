﻿using JustLogic.Core;
[UnitUsage(HideExpressionInActionsList = true)]
[UnitMenu("Event/Get Argument")]
public class JLEventArgument : JLEventArgumentBase
{
}