﻿using JustLogic.Core;

[UnitUsage(HideExpressionInActionsList = true)]
[UnitMenu("Value/Null")]
public class JLNullReference : JLNullReferenceBase
{
}
