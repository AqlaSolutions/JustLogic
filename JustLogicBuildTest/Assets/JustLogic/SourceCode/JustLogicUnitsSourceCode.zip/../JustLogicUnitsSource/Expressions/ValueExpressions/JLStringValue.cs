﻿using JustLogic.Core;

[UnitMenu("Value/String")]
[UnitMenu("String/Value")]
[UnitUsage(typeof(string), HideExpressionInActionsList = true, IsDefaultExpression = true)]
public class JLStringValue : JLStringValueBase
{

}