﻿using System;
using System.Collections.Generic;
using System.Reflection;
using JustLogic.Core;
using UnityEngine;

[UnitMenu("Branch/Sequence")]
public class JLSequence : JLSequenceBase
{
}