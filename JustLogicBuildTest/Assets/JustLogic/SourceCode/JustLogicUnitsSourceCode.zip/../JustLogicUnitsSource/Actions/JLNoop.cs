﻿using System.Collections.Generic;
using JustLogic.Core;

[UnitMenu("Branch/Noop")]
public class JLNoop : JLNoopBase
{
}