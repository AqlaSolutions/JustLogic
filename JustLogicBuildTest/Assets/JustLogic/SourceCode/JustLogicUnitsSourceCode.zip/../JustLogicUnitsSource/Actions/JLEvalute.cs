﻿using System;
using System.Collections.Generic;
using JustLogic.Core;

[UnitFriendlyName("Evaluate Expression")]
[UnitMenu("Branch/Evaluate Expression")]
public class JLEvalute : JLEvaluteBase
{

}