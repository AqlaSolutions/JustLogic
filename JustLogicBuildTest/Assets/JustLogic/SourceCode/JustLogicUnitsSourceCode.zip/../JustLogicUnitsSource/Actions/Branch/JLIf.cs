﻿using System;
using System.Collections.Generic;
using JustLogic.Core;

[UnitMenu("Branch/If")]
public class JLIf : JLIfBase
{

}